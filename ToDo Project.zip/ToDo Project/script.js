const taskEnter = document.getElementById("taskenter");
const taskBorder = document.getElementById('task-border');
const BtnAdd = document.querySelector(".btn");
BtnAdd.addEventListener("click", newTask);

function newTask() {
    if (taskEnter.value != '') {
    // taskBorder.style.visibility = 'visible';
    let newItem = document.createElement("li")
    newItem.innerHTML = taskEnter.value;
    taskBorder.appendChild(newItem);
    let span = document.createElement("span");
    span.innerHTML = "\u00d7";
    newItem.appendChild(span)
    taskEnter.value = '';
    save();
    }
}

window.addEventListener('keydown', function(prs) {
    if(prs.key === 'Enter') {
    newTask();
    }
}, false);


taskBorder.addEventListener("click", function(call) {
    if(call.target.tagName === "LI") {
        call.target.classList.toggle("check");
    }
    
    else if(call.target.tagName === "SPAN") {
        call.target.parentElement.remove();
    }
    save();
}, false);

function save() {
    localStorage.setItem("data", taskBorder.innerHTML);
}

function show() {
    taskBorder.innerHTML = localStorage.getItem("data");
}
show();